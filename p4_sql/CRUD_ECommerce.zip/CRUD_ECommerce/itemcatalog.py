import tkinter as tk
from tkinter import messagebox
import pyodbc

def db_connect():
    try:
        conn = pyodbc.connect(
            'DRIVER={ODBC Driver 17 for SQL Server};'
            'SERVER=localhost,1433;'
            'DATABASE=UniversalMart;'
            'UID=sa;'
            'PWD=Rootroot@97;'
            'TrustServerCertificate=yes;'
            'Timeout=90'
        )
        return conn
    except Exception as e:
        messagebox.showerror("Database Connection", f"Error connecting to database: {e}")
        return None

def insert_item():
    try:
        conn = db_connect()
        if conn:
            cursor = conn.cursor()
            item_id = int(entry_item_id.get())
            catalog_id = int(entry_catalog_id.get())
            item_stock_quantity = int(entry_item_stock_quantity.get())
            item_location = entry_item_location.get()
            received_date = entry_received_date.get()
            cursor.execute("INSERT INTO ITEM_CATALOG (Item_ID, Catalog_ID, Item_Stock_Quantity, Item_Location, Received_Date) VALUES (?, ?, ?, ?, ?)", (item_id, catalog_id, item_stock_quantity, item_location, received_date))
            conn.commit()
            messagebox.showinfo("Success", "Item inserted successfully")
            conn.close()
            view_items()
    except Exception as e:
        messagebox.showerror("Error", f"Error inserting item: {e}")

def update_item():
    try:
        conn = db_connect()
        if conn:
            cursor = conn.cursor()
            item_id = int(entry_item_id.get())
            catalog_id = int(entry_catalog_id.get())
            item_stock_quantity = int(entry_item_stock_quantity.get())
            item_location = entry_item_location.get()
            received_date = entry_received_date.get()
            cursor.execute("UPDATE ITEM_CATALOG SET Item_Stock_Quantity = ?, Item_Location = ?, Received_Date = ? WHERE Item_ID = ? AND Catalog_ID = ?", (item_stock_quantity, item_location, received_date, item_id, catalog_id))
            conn.commit()
            messagebox.showinfo("Success", "Item updated successfully")
            conn.close()
            view_items()
    except Exception as e:
        messagebox.showerror("Error", f"Error updating item: {e}")

def view_items():
    try:
        conn = db_connect()
        if conn:
            cursor = conn.cursor()
            cursor.execute("SELECT * FROM ITEM_CATALOG")
            rows = cursor.fetchall()
            if rows:
                item_text.delete('1.0', tk.END)
                for row in rows:
                    item_text.insert(tk.END, f"Item ID: {row[0]}, Catalog ID: {row[1]}, Quantity: {row[2]}, Location: {row[3]}, Received Date: {row[4]}\n")
            else:
                messagebox.showinfo("No Items", "No items found in the catalog")
            conn.close()
    except Exception as e:
        messagebox.showerror("Error", f"Error viewing items: {e}")

# Create the GUI
root = tk.Tk()
root.title("Item Catalog Management")

# Item ID
label_item_id = tk.Label(root, text="Item ID:")
label_item_id.grid(row=0, column=0)
entry_item_id = tk.Entry(root)
entry_item_id.grid(row=0, column=1)

# Catalog ID
label_catalog_id = tk.Label(root, text="Catalog ID:")
label_catalog_id.grid(row=1, column=0)
entry_catalog_id = tk.Entry(root)
entry_catalog_id.grid(row=1, column=1)

# Item Stock Quantity
label_item_stock_quantity = tk.Label(root, text="Item Stock Quantity:")
label_item_stock_quantity.grid(row=2, column=0)
entry_item_stock_quantity = tk.Entry(root)
entry_item_stock_quantity.grid(row=2, column=1)

# Item Location
label_item_location = tk.Label(root, text="Item Location:")
label_item_location.grid(row=3, column=0)
entry_item_location = tk.Entry(root)
entry_item_location.grid(row=3, column=1)

# Received Date
label_received_date = tk.Label(root, text="Received Date:")
label_received_date.grid(row=4, column=0)
entry_received_date = tk.Entry(root)
entry_received_date.grid(row=4, column=1)

# Buttons
button_insert = tk.Button(root, text="Insert", command=insert_item)
button_insert.grid(row=5, column=0)


button_update = tk.Button(root, text="Update", command=update_item)
button_update.grid(row=6, column=0)

button_view = tk.Button(root, text="View Items", command=view_items)
button_view.grid(row=6, column=1)

# Text widget to display item data
item_text = tk.Text(root, height=10, width=60)
item_text.grid(row=7, columnspan=2, padx=10, pady=10)

root.mainloop()
