import tkinter as tk
from tkinter import messagebox, ttk
import pyodbc

def db_connect():
    try:
        conn = pyodbc.connect(
            'DRIVER={ODBC Driver 17 for SQL Server};'
            'SERVER=localhost,1433;'
            'DATABASE=UniversalMart;'
            'UID=sa;'
            'PWD=Rootroot@97;'
            'TrustServerCertificate=yes;'
            'Timeout=90'
        )
        return conn
    except Exception as e:
        messagebox.showerror("Database Connection", f"Error connecting to database: {e}")
        return None

def insert_utilized_item():
    try:
        conn = db_connect()
        if conn:
            cursor = conn.cursor()
            item_id = int(entry_item_id.get())
            vendor_id = int(entry_vendor_id.get())
            utilized_date = entry_utilized_date.get()
            cursor.execute("INSERT INTO UTILIZED_ITEM (Item_ID, Vendor_ID, Utilized_Date) VALUES (?, ?, ?)",
                           (item_id, vendor_id, utilized_date))
            conn.commit()
            messagebox.showinfo("Success", "Utilized item inserted successfully")
            conn.close()
            view_utilized_items()
    except Exception as e:
        messagebox.showerror("Error", f"Error inserting utilized item: {e}")

def update_utilized_item():
    try:
        conn = db_connect()
        if conn:
            cursor = conn.cursor()
            item_id = int(entry_item_id.get())
            vendor_id = int(entry_vendor_id.get())
            utilized_date = entry_utilized_date.get()
            cursor.execute("UPDATE UTILIZED_ITEM SET Utilized_Date = ? WHERE Item_ID = ? AND Vendor_ID = ?",
                           (utilized_date, item_id, vendor_id))
            conn.commit()
            messagebox.showinfo("Success", "Utilized item updated successfully")
            conn.close()
            view_utilized_items()
    except Exception as e:
        messagebox.showerror("Error", f"Error updating utilized item: {e}")

def view_utilized_items():
    try:
        conn = db_connect()
        if conn:
            cursor = conn.cursor()
            cursor.execute("SELECT * FROM UTILIZED_ITEM")
            rows = cursor.fetchall()
            if rows:
                for row in treeview.get_children():
                    treeview.delete(row)
                for row in rows:
                    treeview.insert("", "end", values=row)
            else:
                messagebox.showinfo("No Utilized Items", "No items found in the utilized items table")
            conn.close()
    except Exception as e:
        messagebox.showerror("Error", f"Error viewing utilized items: {e}")

# Create the GUI
root = tk.Tk()
root.title("Utilized Items Management")

# Set background color
root.configure(bg="#FF9900") 

# Item ID
label_item_id = tk.Label(root, text="Item ID:", bg="#FF9900", fg="black")  
label_item_id.grid(row=0, column=0)
entry_item_id = tk.Entry(root)
entry_item_id.grid(row=0, column=1)

# Vendor ID
label_vendor_id = tk.Label(root, text="Vendor ID:", bg="#FF9900", fg="black")  
label_vendor_id.grid(row=1, column=0)
entry_vendor_id = tk.Entry(root)
entry_vendor_id.grid(row=1, column=1)

# Utilized Date 
label_utilized_date = tk.Label(root, text="Utilized Date:", bg="#FF9900", fg="black") 
label_utilized_date.grid(row=2, column=0)
entry_utilized_date = tk.Entry(root)
entry_utilized_date.grid(row=2, column=1)

# Buttons
button_insert_utilized_item = tk.Button(root, text="Insert Utilized Item", command=insert_utilized_item, bg="#FF9900", fg="blue") 
button_insert_utilized_item.grid(row=3, column=0, pady=10)

button_update_utilized_item = tk.Button(root, text="Update Utilized Item", command=update_utilized_item, bg="#FF9900", fg="blue")  
button_update_utilized_item.grid(row=3, column=1, pady=10)

# Treeview widget to display utilized item data in tabular format
columns = ("Item ID", "Vendor ID", "Utilized Date")
treeview = ttk.Treeview(root, columns=columns, show="headings")
treeview.grid(row=4, column=0, columnspan=2, padx=10, pady=10)

for col in columns:
    treeview.heading(col, text=col)

# Button to view utilized items
button_view_utilized_items = tk.Button(root, text="View Utilized Items", command=view_utilized_items, bg="#FF9900", fg="blue")  
button_view_utilized_items.grid(row=5, column=0, columnspan=2, pady=10)

root.mainloop()
