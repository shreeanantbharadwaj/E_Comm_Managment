import pyodbc
from tkinter import *
from tkinter import messagebox

# Function to establish a connection to the database
def db_connect():
    try:
        conn = pyodbc.connect(
            'DRIVER={ODBC Driver 17 for SQL Server};'
            'SERVER=localhost,1433;'
            'DATABASE=UniversalMart;'
            'UID=sa;'
            'PWD=Rootroot@97;'
            'TrustServerCertificate=yes;'
            'Timeout=90'
        )
        return conn
    except Exception as e:
        messagebox.showerror("Database Connection", f"Error connecting to database: {e}")
        return None

# Function to get the total quantity of an order from the database
def get_order_total_quantity(order_id):
    try:
        conn = db_connect()
        if conn:
            cursor = conn.cursor()
            # Execute the stored procedure with OUTPUT parameter
            cursor.execute("DECLARE @Total_Quantity INT; EXEC GetOrderTotalQuantity ?, @Total_Quantity OUTPUT; SELECT @Total_Quantity;", order_id)
            # Fetch the result from the output parameter
            total_quantity = cursor.fetchone()[0]
            conn.close()
            return total_quantity
    except Exception as e:
        messagebox.showerror("Error", f"Error retrieving order total quantity: {e}")

# Function to handle the get total quantity button click event
def get_total_quantity():
    order_id = order_id_entry.get()
    if order_id:
        total_quantity = get_order_total_quantity(int(order_id))
        if total_quantity is not None:
            messagebox.showinfo("Total Quantity", f"The total quantity for order {order_id} is: {total_quantity}")
    else:
        messagebox.showerror("Error", "Please enter order ID.")

# Create the main Tkinter window
root = Tk()
root.title("Get Order Total Quantity")

# Set background color to Amazon-themed color
root.configure(bg='#ff9900')

# Get the screen width and height
screen_width = root.winfo_screenwidth()
screen_height = root.winfo_screenheight()

# Set window size and position
window_width = 400
window_height = 200
x_position = (screen_width - window_width) // 2
y_position = (screen_height - window_height) // 2
root.geometry(f"{window_width}x{window_height}+{x_position}+{y_position}")

# Create and place labels and entry fields with Amazon-themed color
order_id_label = Label(root, text="Order ID:", bg='#ff9900', fg='black')
order_id_label.grid(row=0, column=0, padx=10, pady=5, sticky=W)
order_id_entry = Entry(root)
order_id_entry.grid(row=0, column=1, padx=10, pady=5)

# Create and place get total quantity button with Amazon-themed color
get_total_quantity_button = Button(root, text="Get Total Quantity", command=get_total_quantity, bg='#ff9900', fg='black')
get_total_quantity_button.grid(row=1, column=0, columnspan=2, padx=10, pady=10)

# Run the Tkinter event loop
root.mainloop()
