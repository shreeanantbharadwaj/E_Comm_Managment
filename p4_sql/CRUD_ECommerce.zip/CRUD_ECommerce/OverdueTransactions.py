import tkinter as tk
from tkinter import messagebox
import pyodbc

def db_connect():
    try:
        conn = pyodbc.connect(
            'DRIVER={ODBC Driver 17 for SQL Server};'
            'SERVER=localhost,1433;'
            'DATABASE=UniversalMart;'
            'UID=sa;'
            'PWD=Rootroot@97;'
            'TrustServerCertificate=yes;'
            'Timeout=90'
        )
        return conn
    except Exception as e:
        messagebox.showerror("Database Connection", f"Error connecting to database: {e}")
        return None

def fetch_overdue_transactions():
    conn = db_connect()
    if conn:
        try:
            cursor = conn.cursor()
            cursor.execute("SELECT Transaction_ID, Amount, Transaction_Status, Transaction_method FROM OverdueTransactions")
            rows = cursor.fetchall()
            conn.close()
            return rows
        except Exception as e:
            messagebox.showerror("Error", f"Error fetching data: {e}")
            conn.close()
            return None

def display_overdue_transactions():
    overdue_transactions = fetch_overdue_transactions()
    if overdue_transactions:
        listbox.delete(0, tk.END)
        for transaction in overdue_transactions:
            listbox.insert(tk.END, f"Transaction ID: {transaction[0]}, Amount: {transaction[1]}, Status: {transaction[2]}, Method: {transaction[3]}")

root = tk.Tk()
root.title("Overdue Transactions")
root.geometry("500x300")
root.configure(bg='#232F3E')

listbox = tk.Listbox(root, width=70, height=15, bg='#37475A', fg='#FFD814')
listbox.pack(pady=20)

fetch_button = tk.Button(root, text="Fetch Overdue Transactions", command=display_overdue_transactions, bg='#FF9900', fg='#0F1111')
fetch_button.pack()

root.mainloop()
