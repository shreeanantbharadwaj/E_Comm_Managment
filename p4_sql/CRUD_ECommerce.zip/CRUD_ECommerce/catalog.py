import tkinter as tk
from tkinter import messagebox
import pyodbc

def db_connect():
    try:
        conn = pyodbc.connect(
            'DRIVER={ODBC Driver 17 for SQL Server};'
            'SERVER=localhost,1433;'
            'DATABASE=UniversalMart;'
            'UID=sa;'
            'PWD=Rootroot@97;'
            'TrustServerCertificate=yes;'
            'Timeout=90'
        )
        return conn
    except Exception as e:
        messagebox.showerror("Database Connection", f"Error connecting to database: {e}")
        return None

def insert_catalog():
    try:
        conn = db_connect()
        if conn:
            cursor = conn.cursor()
            catalog_id = int(entry_catalog_id.get())
            catalog_category = entry_catalog_category.get()
            cursor.execute("INSERT INTO CATALOG (Catalog_ID, Catalog_Category) VALUES (?, ?)", (catalog_id, catalog_category))
            conn.commit()
            messagebox.showinfo("Success", "Catalog inserted successfully")
            conn.close()
            view_catalogs()
    except Exception as e:
        messagebox.showerror("Error", f"Error inserting catalog: {e}")

def delete_catalog():
    try:
        conn = db_connect()
        if conn:
            cursor = conn.cursor()
            catalog_id = int(entry_catalog_id.get())
            cursor.execute("DELETE FROM CATALOG WHERE Catalog_ID = ?", (catalog_id,))
            conn.commit()
            messagebox.showinfo("Success", "Catalog deleted successfully")
            conn.close()
            view_catalogs()
    except Exception as e:
        messagebox.showerror("Error", f"Error deleting catalog: {e}")

def update_catalog():
    try:
        conn = db_connect()
        if conn:
            cursor = conn.cursor()
            catalog_id = int(entry_catalog_id.get())
            catalog_category = entry_catalog_category.get()
            cursor.execute("UPDATE CATALOG SET Catalog_Category = ? WHERE Catalog_ID = ?", (catalog_category, catalog_id))
            conn.commit()
            messagebox.showinfo("Success", "Catalog updated successfully")
            conn.close()
            view_catalogs()
    except Exception as e:
        messagebox.showerror("Error", f"Error updating catalog: {e}")

def view_catalogs():
    try:
        conn = db_connect()
        if conn:
            cursor = conn.cursor()
            cursor.execute("SELECT * FROM CATALOG")
            rows = cursor.fetchall()
            if rows:
                catalog_text.delete('1.0', tk.END)
                for row in rows:
                    catalog_text.insert(tk.END, f"Catalog ID: {row[0]}, Category: {row[1]}\n")
            else:
                messagebox.showinfo("No Catalogs", "No catalogs found")
            conn.close()
    except Exception as e:
        messagebox.showerror("Error", f"Error viewing catalogs: {e}")

root = tk.Tk()
root.title("Catalog Management")
root.configure(bg='#639feb')
root.state('normal')
root.update_idletasks()
width = root.winfo_screenwidth()
height = root.winfo_screenheight()
root.geometry(f'{width}x{height}+0+0')

entry_bg = '#FFD814'
entry_fg = '#0F1111'
button_bg = '#FF9900'
button_fg = '#0F1111'
text_widget_bg = '#37475A'
text_widget_fg = '#FFD814'

label_catalog_id = tk.Label(root, text="Catalog ID:", bg='#639feb', fg=entry_fg)
label_catalog_id.grid(row=0, column=0)
entry_catalog_id = tk.Entry(root, bg=entry_bg, fg=entry_fg)
entry_catalog_id.grid(row=0, column=1)

label_catalog_category = tk.Label(root, text="Catalog Category:", bg='#639feb', fg=entry_fg)
label_catalog_category.grid(row=1, column=0)
entry_catalog_category = tk.Entry(root, bg=entry_bg, fg=entry_fg)
entry_catalog_category.grid(row=1, column=1)

button_insert = tk.Button(root, text="Insert", command=insert_catalog, bg=button_bg, fg=button_fg)
button_insert.grid(row=2, column=0)

button_delete = tk.Button(root, text="Delete", command=delete_catalog, bg=button_bg, fg=button_fg)
button_delete.grid(row=2, column=1)

button_update = tk.Button(root, text="Update", command=update_catalog, bg=button_bg, fg=button_fg)
button_update.grid(row=3, column=0)

button_view = tk.Button(root, text="View Catalogs", command=view_catalogs, bg=button_bg, fg=button_fg)
button_view.grid(row=3, column=1)

catalog_text = tk.Text(root, height=10, width=40, bg=text_widget_bg, fg=text_widget_fg)
catalog_text.grid(row=4, columnspan=2, padx=10, pady=10)

root.mainloop()
