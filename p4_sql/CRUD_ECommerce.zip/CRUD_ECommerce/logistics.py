import tkinter as tk
from tkinter import messagebox
import pyodbc

def db_connect():
    try:
        conn = pyodbc.connect(
            'DRIVER={ODBC Driver 17 for SQL Server};'
            'SERVER=localhost,1433;'
            'DATABASE=UniversalMart;'
            'UID=sa;'
            'PWD=Rootroot@97;'
            'TrustServerCertificate=yes;'
            'Timeout=90'
        )
        return conn
    except Exception as e:
        messagebox.showerror("Database Connection", f"Error connecting to database: {e}")
        return None

def insert_international_logistics():
    try:
        conn = db_connect()
        if conn:
            cursor = conn.cursor()
            international_id = int(entry_international_id.get())
            tariff = entry_international_tariff.get()
            warehouse = entry_international_warehouse.get()
            custom_duty = entry_international_custom_duty.get()
            cursor.execute("INSERT INTO International_Logistics (International_Logistics_ID, International_Tariff, International_Warehouse, Custom_Duty) VALUES (?, ?, ?, ?)", (international_id, tariff, warehouse, custom_duty))
            conn.commit()
            messagebox.showinfo("Success", "International logistics record inserted successfully")
            conn.close()
    except Exception as e:
        messagebox.showerror("Error", f"Error inserting international logistics record: {e}")

def delete_international_logistics():
    try:
        conn = db_connect()
        if conn:
            cursor = conn.cursor()
            international_id = int(entry_international_id.get())
            cursor.execute("DELETE FROM International_Logistics WHERE International_Logistics_ID = ?", (international_id,))
            conn.commit()
            messagebox.showinfo("Success", "International logistics record deleted successfully")
            conn.close()
    except Exception as e:
        messagebox.showerror("Error", f"Error deleting international logistics record: {e}")

def update_international_logistics():
    try:
        conn = db_connect()
        if conn:
            cursor = conn.cursor()
            international_id = int(entry_international_id.get())
            tariff = entry_international_tariff.get()
            warehouse = entry_international_warehouse.get()
            custom_duty = entry_international_custom_duty.get()
            cursor.execute("UPDATE International_Logistics SET International_Tariff = ?, International_Warehouse = ?, Custom_Duty = ? WHERE International_Logistics_ID = ?", (tariff, warehouse, custom_duty, international_id))
            conn.commit()
            messagebox.showinfo("Success", "International logistics record updated successfully")
            conn.close()
    except Exception as e:
        messagebox.showerror("Error", f"Error updating international logistics record: {e}")

def insert_domestic_logistics():
    try:
        conn = db_connect()
        if conn:
            cursor = conn.cursor()
            domestic_id = int(entry_domestic_id.get())
            state_transfer_charges = entry_domestic_state_transfer_charges.get()
            cursor.execute("INSERT INTO Domestic_Logistics (Domestic_Logistics_ID, State_Transfer_Charges) VALUES (?, ?)", (domestic_id, state_transfer_charges))
            conn.commit()
            messagebox.showinfo("Success", "Domestic logistics record inserted successfully")
            conn.close()
    except Exception as e:
        messagebox.showerror("Error", f"Error inserting domestic logistics record: {e}")

def delete_domestic_logistics():
    try:
        conn = db_connect()
        if conn:
            cursor = conn.cursor()
            domestic_id = int(entry_domestic_id.get())
            cursor.execute("DELETE FROM Domestic_Logistics WHERE Domestic_Logistics_ID = ?", (domestic_id,))
            conn.commit()
            messagebox.showinfo("Success", "Domestic logistics record deleted successfully")
            conn.close()
    except Exception as e:
        messagebox.showerror("Error", f"Error deleting domestic logistics record: {e}")

def update_domestic_logistics():
    try:
        conn = db_connect()
        if conn:
            cursor = conn.cursor()
            domestic_id = int(entry_domestic_id.get())
            state_transfer_charges = entry_domestic_state_transfer_charges.get()
            cursor.execute("UPDATE Domestic_Logistics SET State_Transfer_Charges = ? WHERE Domestic_Logistics_ID = ?", (state_transfer_charges, domestic_id))
            conn.commit()
            messagebox.showinfo("Success", "Domestic logistics record updated successfully")
            conn.close()
    except Exception as e:
        messagebox.showerror("Error", f"Error updating domestic logistics record: {e}")

root = tk.Tk()
root.title("Logistics Management")
root.configure(bg='#232F3E')
root.geometry('800x600+100+100')

frame_international = tk.LabelFrame(root, text="International Logistics", bg='#232F3E', fg='#FFD814')
frame_international.grid(row=0, column=0, padx=10, pady=10, sticky='ew')

entry_bg = '#37475A'
entry_fg = '#FFD814'
button_bg = '#FF9900'
button_fg = '#0F1111'

label_international_id = tk.Label(frame_international, text="Logistics ID:", bg='#232F3E', fg='#FFD814')
label_international_id.grid(row=0, column=0)
entry_international_id = tk.Entry(frame_international, bg=entry_bg, fg=entry_fg)
entry_international_id.grid(row=0, column=1)

label_international_tariff = tk.Label(frame_international, text="Tariff:", bg='#232F3E', fg='#FFD814')
label_international_tariff.grid(row=1, column=0)
entry_international_tariff = tk.Entry(frame_international, bg=entry_bg, fg=entry_fg)
entry_international_tariff.grid(row=1, column=1)

label_international_warehouse = tk.Label(frame_international, text="Warehouse:", bg='#232F3E', fg='#FFD814')
label_international_warehouse.grid(row=2, column=0)
entry_international_warehouse = tk.Entry(frame_international, bg=entry_bg, fg=entry_fg)
entry_international_warehouse.grid(row=2, column=1)

label_international_custom_duty = tk.Label(frame_international, text="Custom Duty:", bg='#232F3E', fg='#FFD814')
label_international_custom_duty.grid(row=3, column=0)
entry_international_custom_duty = tk.Entry(frame_international, bg=entry_bg, fg=entry_fg)
entry_international_custom_duty.grid(row=3, column=1)

button_insert_international = tk.Button(frame_international, text="Insert", command=insert_international_logistics, bg=button_bg, fg=button_fg)
button_insert_international.grid(row=4, column=0)

button_delete_international = tk.Button(frame_international, text="Delete", command=delete_international_logistics, bg=button_bg, fg=button_fg)
button_delete_international.grid(row=4, column=1)

button_update_international = tk.Button(frame_international, text="Update", command=update_international_logistics, bg=button_bg, fg=button_fg)
button_update_international.grid(row=5, column=0)

frame_domestic = tk.LabelFrame(root, text="Domestic Logistics", bg='#232F3E', fg='#FFD814')
frame_domestic.grid(row=0, column=1, padx=10, pady=10, sticky='ew')

label_domestic_id = tk.Label(frame_domestic, text="Logistics ID:", bg='#232F3E', fg='#FFD814')
label_domestic_id.grid(row=0, column=0)
entry_domestic_id = tk.Entry(frame_domestic, bg=entry_bg, fg=entry_fg)
entry_domestic_id.grid(row=0, column=1)

label_domestic_state_transfer_charges = tk.Label(frame_domestic, text="State Transfer Charges:", bg='#232F3E', fg='#FFD814')
label_domestic_state_transfer_charges.grid(row=1, column=0)
entry_domestic_state_transfer_charges = tk.Entry(frame_domestic, bg=entry_bg, fg=entry_fg)
entry_domestic_state_transfer_charges.grid(row=1, column=1)

button_insert_domestic = tk.Button(frame_domestic, text="Insert", command=insert_domestic_logistics, bg=button_bg, fg=button_fg)
button_insert_domestic.grid(row=2, column=0)

button_delete_domestic = tk.Button(frame_domestic, text="Delete", command=delete_domestic_logistics, bg=button_bg, fg=button_fg)
button_delete_domestic.grid(row=2, column=1)

button_update_domestic = tk.Button(frame_domestic, text="Update", command=update_domestic_logistics, bg=button_bg, fg=button_fg)
button_update_domestic.grid(row=3, column=0)

root.mainloop()
