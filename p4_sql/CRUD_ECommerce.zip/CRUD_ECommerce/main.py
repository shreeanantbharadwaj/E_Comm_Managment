import tkinter as tk
import os

def run_script(script_name):
    os.system(f'python {script_name}')

app = tk.Tk()
app.title('Universal Mart')

window_width = 800
window_height = 600
screen_width = app.winfo_screenwidth()
screen_height = app.winfo_screenheight()
center_x = int(screen_width/2 - window_width / 2)
center_y = int(screen_height/2 - window_height / 2)
app.geometry(f'{window_width}x{window_height}+{center_x}+{center_y}')

background_color = '#131A22'  
button_color = '#FFD814'      
text_color = '#0F1111'        
border_color = '#FF9900'      

app.config(bg=background_color)

heading_label = tk.Label(app, text='Universal Mart', bg=background_color, fg='white', font=('Arial', 24, 'bold'))
heading_label.pack(pady=20)

# Define button properties
button_font = ('Arial', 10)
button_padx = 10
button_pady = 5
button_borderwidth = 2

script_names = [
    'ActiveConsumers.py', 'CalculateDiscountAmount.py', 'catalog.py', 'classification.py',
    'consumers.py', 'billing.py', 'DeliveryStatus.py', 'GetConsumerDetails.py',
    'GetOrderTotalQuantity.py', 'item.py', 'itemcatalog.py', 'logistics.py', 
    'order.py', 'orderline.py', 'OverdueTransactions.py', 'ReduceItemStockOnOrder.py', 
    'review.py', 'transactions.py', 'updateitemcost.py', 'utilizeditem.py', 'vendor.py'
]

button_names = [
    'Active Consumers', 'Calculate Discount Amount', 'Catalog', 'Classification',
    'Consumers', 'Billing', 'Delivery Status', 'Get Consumer Details',
    'Get Order Total Quantity', 'Item', 'Item Catalog', 'Logistics', 
    'Order', 'Order Line', 'Overdue Transactions', 'Reduce Item Stock On Order', 
    'Review', 'Transactions', 'Update Item Cost', 'Utilized Item', 'Vendor'
]

buttons_frame = tk.Frame(app, bg=background_color)
buttons_frame.pack()

# Add buttons for each script with custom names
for script_name, button_name in zip(script_names, button_names):
    button = tk.Button(buttons_frame, text=button_name, 
                       command=lambda n=script_name: run_script(n),
                       bg=button_color, fg=text_color, font=button_font,
                       padx=button_padx, pady=button_pady,
                       highlightbackground=border_color, highlightthickness=button_borderwidth, bd=0)
    button.pack(side='top', pady=5, fill='x')

# Run the app
app.mainloop()
