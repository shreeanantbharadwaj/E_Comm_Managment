import tkinter as tk
from tkinter import messagebox, ttk
import pyodbc

def db_connect():
    try:
        conn = pyodbc.connect(
            'DRIVER={ODBC Driver 17 for SQL Server};'
            'SERVER=localhost,1433;'
            'DATABASE=UniversalMart;'
            'UID=sa;'
            'PWD=Rootroot@97;'
            'TrustServerCertificate=yes;'
            'Timeout=90'
        )
        return conn
    except Exception as e:
        messagebox.showerror("Database Connection", f"Error connecting to database: {e}")
        return None

def insert_classification():
    try:
        conn = db_connect()
        if conn:
            cursor = conn.cursor()
            classification_id = int(entry_classification_id.get())
            classification_name = entry_classification_name.get()
            cursor.execute("INSERT INTO Classification (Classification_ID, Classification_Name) VALUES (?, ?)", (classification_id, classification_name))
            conn.commit()
            messagebox.showinfo("Success", "Classification record inserted successfully")
            conn.close()
    except Exception as e:
        messagebox.showerror("Error", f"Error inserting classification record: {e}")

def delete_classification():
    try:
        conn = db_connect()
        if conn:
            cursor = conn.cursor()
            classification_id = int(entry_classification_id.get())
            cursor.execute("DELETE FROM Classification WHERE Classification_ID = ?", (classification_id,))
            conn.commit()
            messagebox.showinfo("Success", "Classification record deleted successfully")
            conn.close()
    except Exception as e:
        messagebox.showerror("Error", f"Error deleting classification record: {e}")

def update_classification():
    try:
        conn = db_connect()
        if conn:
            cursor = conn.cursor()
            classification_id = int(entry_classification_id.get())
            classification_name = entry_classification_name.get()
            cursor.execute("UPDATE Classification SET Classification_Name = ? WHERE Classification_ID = ?", (classification_name, classification_id))
            conn.commit()
            messagebox.showinfo("Success", "Classification record updated successfully")
            conn.close()
    except Exception as e:
        messagebox.showerror("Error", f"Error updating classification record: {e}")

def view_classification():
    try:
        conn = db_connect()
        if conn:
            cursor = conn.cursor()
            cursor.execute("SELECT * FROM Classification")
            rows = cursor.fetchall()
            if rows:
                view_window = tk.Toplevel()
                view_window.title("Classification Data")
                tree = ttk.Treeview(view_window)
                tree["columns"] = ("Classification ID", "Classification Name")
                tree.heading("#0", text="Index")
                tree.heading("Classification ID", text="Classification ID")
                tree.heading("Classification Name", text="Classification Name")
                for i, row in enumerate(rows):
                    tree.insert("", tk.END, text=str(i+1), values=row)
                tree.pack(expand=True, fill="both")
            else:
                messagebox.showinfo("No Data", "No classification data found")
            conn.close()
    except Exception as e:
        messagebox.showerror("Error", f"Error viewing classification data: {e}")

root = tk.Tk()
root.title("Classification Management")
root.configure(bg='#232F3E')

# Centering the window
window_width = 400
window_height = 200
screen_width = root.winfo_screenwidth()
screen_height = root.winfo_screenheight()
center_x = int(screen_width/2 - window_width / 2)
center_y = int(screen_height/2 - window_height / 2)
root.geometry(f'{window_width}x{window_height}+{center_x}+{center_y}')

# Color scheme
entry_bg = '#FFD814'
entry_fg = '#0F1111'
button_bg = '#FF9900'
button_fg = '#0F1111'
label_fg = '#FFFFFF'

label_classification_id = tk.Label(root, text="Classification ID:", bg='#232F3E', fg=label_fg)
label_classification_id.grid(row=0, column=0)
entry_classification_id = tk.Entry(root, bg=entry_bg, fg=entry_fg)
entry_classification_id.grid(row=0, column=1)

label_classification_name = tk.Label(root, text="Classification Name:", bg='#232F3E', fg=label_fg)
label_classification_name.grid(row=1, column=0)
entry_classification_name = tk.Entry(root, bg=entry_bg, fg=entry_fg)
entry_classification_name.grid(row=1, column=1)

button_insert = tk.Button(root, text="Insert", command=insert_classification, bg=button_bg, fg=button_fg)
button_insert.grid(row=2, column=0)

button_delete = tk.Button(root, text="Delete", command=delete_classification, bg=button_bg, fg=button_fg)
button_delete.grid(row=2, column=1)

button_update = tk.Button(root, text="Update", command=update_classification, bg=button_bg, fg=button_fg)
button_update.grid(row=3, column=0)

button_view = tk.Button(root, text="View", command=view_classification, bg=button_bg, fg=button_fg)
button_view.grid(row=3, column=1)

root.mainloop()
