import tkinter as tk
from tkinter import ttk, messagebox
import pyodbc

def db_connect():
    try:
        conn = pyodbc.connect(
            'DRIVER={ODBC Driver 17 for SQL Server};'
            'SERVER=localhost,1433;'
            'DATABASE=UniversalMart;'
            'UID=sa;'
            'PWD=Rootroot@97;'
            'TrustServerCertificate=yes;'
            'Timeout=90'
        )
        return conn
    except Exception as e:
        messagebox.showerror("Database Connection", f"Error connecting to database: {e}")
        return None

def execute_query(query, parameters=None, fetch_results=False):
    conn = db_connect()
    if conn:
        cursor = conn.cursor()
        if parameters:
            cursor.execute(query, parameters)
        else:
            cursor.execute(query)
        if fetch_results:
            results = cursor.fetchall()
            conn.close()
            return results
        conn.commit()
        conn.close()

def transaction_exists(transaction_id):
    query = "SELECT COUNT(*) FROM TRANSACTION_INFORMATION WHERE Transaction_ID = ?"
    result = execute_query(query, (transaction_id,), fetch_results=True)
    return result and result[0][0] > 0

def consumer_exists(consumer_id):
    query = "SELECT COUNT(*) FROM CONSUMER WHERE Consumer_ID = ?"
    result = execute_query(query, (consumer_id,), fetch_results=True)
    return result and result[0][0] > 0

def billing_has_orders(billing_id):
    try:
        billing_id = int(billing_id)
    except ValueError:
        messagebox.showerror("Error", "Invalid Billing ID.")
        return False
    query = "SELECT COUNT(*) FROM [ORDER] WHERE Billing_ID = ?"
    result = execute_query(query, (billing_id,), fetch_results=True)
    return result and result[0][0] > 0

class BillingApp:
    def __init__(self, root):
        self.root = root
        self.root.title("Billing Management")
        self.setup_ui()

    def setup_ui(self):
        self.root.state('normal')
        self.root.update_idletasks()
        width = self.root.winfo_screenwidth()
        height = self.root.winfo_screenheight()
        self.root.geometry(f'{width}x{height}+0+0')
        self.root.configure(bg='#FF9900')
        entry_bg = '#FFF2CC'
        button_bg = '#146EB4'
        text_color = '#000000'
        entry_fields = ['billing_id_entry', 'delivery_address_entry', 'deadline_date_entry', 'billing_status_entry', 'transaction_id_entry', 'consumer_id_entry']
        row = 0
        for field in entry_fields:
            setattr(self, field, tk.Entry(self.root, bg=entry_bg, fg=text_color))
            getattr(self, field).grid(row=row, column=1, padx=10, pady=10, sticky="ew")
            tk.Label(self.root, text=field.replace('_', ' ').title() + ":", bg='#FF9900', fg=text_color).grid(row=row, column=0, padx=10, pady=10, sticky='w')
            row += 1
        button_texts = ['Add Billing', 'Update Billing', 'Delete Billing']
        commands = [self.add_billing, self.update_billing, self.delete_billing]
        for i, (text, command) in enumerate(zip(button_texts, commands)):
            tk.Button(self.root, text=text, command=command, bg=button_bg, fg=text_color).grid(row=6+i//2, column=i%2, padx=10, pady=10, sticky="ew")
        self.billing_records = ttk.Treeview(self.root, columns=("Billing_ID", "Delivery_Address", "Deadline_Date", "Billing_Status", "Transaction_ID", "Consumer_ID"), show="headings")
        self.billing_records.grid(row=8, column=0, columnspan=2, padx=10, pady=10, sticky='nsew')
        for col in self.billing_records['columns']:
            self.billing_records.heading(col, text=col)
        self.load_billings()

    def add_billing(self):
        if not transaction_exists(self.transaction_id_entry.get()):
            messagebox.showerror("Error", "Transaction ID does not exist.")
            return
        if not consumer_exists(self.consumer_id_entry.get()):
            messagebox.showerror("Error", "Consumer does not exist.")
            return
        query = "INSERT INTO BILLING (Billing_ID, Delivery_Address, Deadline_Date, Billing_Status, Transaction_ID, Consumer_ID) VALUES (?, ?, ?, ?, ?, ?)"
        parameters = (
            self.billing_id_entry.get(),
            self.delivery_address_entry.get(),
            self.deadline_date_entry.get(),
            self.billing_status_entry.get(),
            self.transaction_id_entry.get(),
            self.consumer_id_entry.get()
        )
        execute_query(query, parameters)
        messagebox.showinfo("Success", "Billing record added successfully!")
        self.clear_entries()
        self.load_billings()

    def update_billing(self):
        if not transaction_exists(self.transaction_id_entry.get()):
            messagebox.showerror("Error", "Transaction ID does not exist.")
            return
        if not consumer_exists(self.consumer_id_entry.get()):
            messagebox.showerror("Error", "Consumer does not exist.")
            return
        selected_item = self.billing_records.focus()
        billing_id = self.billing_records.item(selected_item, 'values')[0]
        query = "UPDATE BILLING SET Delivery_Address=?, Deadline_Date=?, Billing_Status=?, Transaction_ID=?, Consumer_ID=? WHERE Billing_ID=?"
        parameters = (
            self.delivery_address_entry.get(),
            self.deadline_date_entry.get(),
            self.billing_status_entry.get(),
            self.transaction_id_entry.get(),
            self.consumer_id_entry.get(),
            billing_id
        )
        execute_query(query, parameters)
        messagebox.showinfo("Success", "Billing record updated successfully!")
        self.clear_entries()
        self.load_billings()

    def delete_billing(self):
        selected_item = self.billing_records.focus()
        if not selected_item:
            messagebox.showwarning("Selection Required", "Please select a billing record to delete.")
            return
        billing_id = self.billing_records.item(selected_item, 'values')[0]
        if billing_has_orders(billing_id):
            confirmation = messagebox.askyesno("Confirm Delete", "This billing record is referenced by one or more orders. Are you sure you want to delete it?")
            if not confirmation:
                return
        query = "DELETE FROM BILLING WHERE Billing_ID=?"
        execute_query(query, (billing_id,))
        messagebox.showinfo("Success", "Billing record deleted successfully!")
        self.load_billings()

    def load_billings(self):
        for record in self.billing_records.get_children():
            self.billing_records.delete(record)
        query = """
        SELECT b.Billing_ID, b.Billing_Date, b.Delivery_Address, b.Deadline_Date, b.Billing_Status, 
            b.Transaction_ID, b.Consumer_ID
        FROM BILLING b
        INNER JOIN CONSUMER c ON b.Consumer_ID = c.Consumer_ID
        INNER JOIN TRANSACTION_INFORMATION t ON b.Transaction_ID = t.Transaction_ID
        """
        records = execute_query(query, fetch_results=True)
        for row in records:
            self.billing_records.insert('', 'end', values=row)

    def clear_entries(self):
        self.billing_id_entry.delete(0, tk.END)
        self.delivery_address_entry.delete(0, tk.END)
        self.deadline_date_entry.delete(0, tk.END)
        self.billing_status_entry.delete(0, tk.END)
        self.transaction_id_entry.delete(0, tk.END)
        self.consumer_id_entry.delete(0, tk.END)

if __name__ == "__main__":
    root = tk.Tk()
    app = BillingApp(root)
    root.mainloop()
