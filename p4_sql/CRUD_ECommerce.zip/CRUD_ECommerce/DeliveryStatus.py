import tkinter as tk
from tkinter import messagebox
import pyodbc

# Database connection function
def db_connect():
    try:
        conn = pyodbc.connect(
            'DRIVER={ODBC Driver 17 for SQL Server};'
            'SERVER=localhost,1433;'
            'DATABASE=UniversalMart;'
            'UID=sa;'
            'PWD=Rootroot@97;'
            'TrustServerCertificate=yes;'
            'Timeout=90'
        )
        return conn
    except Exception as e:
        messagebox.showerror("Database Connection", f"Error connecting to database: {e}")
        return None

# Function to fetch delivery status summary from the database
def fetch_delivery_status_summary():
    conn = db_connect()
    if conn:
        try:
            cursor = conn.cursor()
            cursor.execute("SELECT Delivery_Status, COUNT(*) AS NumberOfDeliveries FROM DeliveryStatusSummary GROUP BY Delivery_Status")
            rows = cursor.fetchall()
            conn.close()
            return rows
        except Exception as e:
            messagebox.showerror("Error", f"Error fetching data: {e}")
            conn.close()
            return None

# Function to display delivery status summary in a listbox
def display_delivery_status_summary():
    delivery_summary = fetch_delivery_status_summary()
    if delivery_summary:
        listbox.delete(0, tk.END)
        for status, count in delivery_summary:
            listbox.insert(tk.END, f"{status}: {count}")

# Tkinter setup
root = tk.Tk()
root.title("Delivery Status Summary")
root.geometry("400x300")

# Set background color
root.configure(bg="#FFA500")

# Center the window
window_width = root.winfo_reqwidth()
window_height = root.winfo_reqheight()
position_right = int(root.winfo_screenwidth()/2 - window_width/2)
position_down = int(root.winfo_screenheight()/2 - window_height/2)
root.geometry("+{}+{}".format(position_right, position_down))

# Listbox to display delivery status summary
listbox = tk.Listbox(root, width=50, height=10, bg="#FFA500", fg="#232f3e", bd=0)
listbox.pack(pady=20)

# Button to fetch and display delivery status summary
fetch_button = tk.Button(root, text="Fetch Delivery Status Summary", command=display_delivery_status_summary, bg="#FFA500", fg="#FFA500", bd=0)
fetch_button.pack()

# Run the Tkinter event loop
root.mainloop()
