import pyodbc
from tkinter import *
from tkinter import messagebox

# Function to connect to the database
def db_connect():
    try:
        conn = pyodbc.connect(
            'DRIVER={ODBC Driver 17 for SQL Server};'
            'SERVER=localhost,1433;'
            'DATABASE=UniversalMart;'
            'UID=sa;'
            'PWD=Rootroot@97;'
            'TrustServerCertificate=yes;'
            'Timeout=90'
        )
        return conn
    except Exception as e:
        messagebox.showerror("Database Connection", f"Error connecting to database: {e}")
        return None

# Function to execute the stored procedure GetConsumerDetails
def get_consumer_details(consumer_id):
    try:
        # Establish a connection to the database
        conn = db_connect()
        if conn is None:
            return

        # Create a cursor
        cursor = conn.cursor()

        # Execute the stored procedure
        cursor.execute("{CALL GetConsumerDetails (?, ?, ?, ?, ?, ?, ?)}", (consumer_id, '', '', '', '', '', ''))

        # Fetch the result
        row = cursor.fetchone()

        # Display the result
        if row:
            given_name, family_name, email_address, contact_number, postal_address, consumer_status = row
            messagebox.showinfo("Consumer Details", 
                                f"Given Name: {given_name}\n"
                                f"Family Name: {family_name}\n"
                                f"Email Address: {email_address}\n"
                                f"Contact Number: {contact_number}\n"
                                f"Postal Address: {postal_address}\n"
                                f"Consumer Status: {consumer_status}")
        else:
            messagebox.showinfo("Consumer Details", "No results found for the given consumer ID.")

        # Close the cursor and connection
        cursor.close()
        conn.close()
    except Exception as e:
        messagebox.showerror("Error", f"Error retrieving consumer details: {e}")

# Function to handle button click event
def on_click():
    consumer_id = int(entry.get())
    get_consumer_details(consumer_id)

# Create a GUI window
root = Tk()
root.title("Get Consumer Details")

# Set background color to Amazon-themed color
root.configure(bg='#ff9900')

# Get the screen width and height
screen_width = root.winfo_screenwidth()
screen_height = root.winfo_screenheight()

# Set window size and position
window_width = 400
window_height = 200
x_position = (screen_width - window_width) // 2
y_position = (screen_height - window_height) // 2
root.geometry(f"{window_width}x{window_height}+{x_position}+{y_position}")

# Create labels and entry
Label(root, text="Consumer ID:", bg='#ff9900', fg='black').grid(row=0, column=0)
entry = Entry(root)
entry.grid(row=0, column=1)

# Create a button to retrieve consumer details
Button(root, text="Get Details", command=on_click, bg='#ff9900', fg='black').grid(row=1, columnspan=2)

# Run the GUI
root.mainloop()
