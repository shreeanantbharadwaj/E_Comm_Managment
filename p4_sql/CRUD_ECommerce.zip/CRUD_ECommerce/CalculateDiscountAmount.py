import pyodbc
from tkinter import *
from tkinter import messagebox

def db_connect():
    try:
        conn = pyodbc.connect(
            'DRIVER={ODBC Driver 17 for SQL Server};'
            'SERVER=localhost,1433;'
            'DATABASE=UniversalMart;'
            'UID=sa;'
            'PWD=Rootroot@97;'
            'TrustServerCertificate=yes;'
            'Timeout=90'
        )
        return conn
    except Exception as e:
        messagebox.showerror("Database Connection", f"Error connecting to database: {e}")
        return None

def calculate_discount(cost, discount_rate):
    try:
        conn = db_connect()
        if conn:
            cursor = conn.cursor()
            cursor.execute("SELECT dbo.CalculateDiscountAmount(?, ?) AS DiscountAmount", (cost, discount_rate))
            row = cursor.fetchone()
            if row:
                discount_amount = row.DiscountAmount
                messagebox.showinfo("Discount Amount", f"The discount amount is: {discount_amount}")
            else:
                messagebox.showerror("Error", "No results returned.")
    except pyodbc.Error as e:
        messagebox.showerror("Error", f"Error retrieving discount amount: {e}")
    finally:
        if conn:
            conn.close()

def get_discount_amount():
    cost = cost_entry.get()
    discount_rate = discount_rate_entry.get()
    if cost and discount_rate:
        calculate_discount(float(cost), float(discount_rate))
    else:
        messagebox.showerror("Error", "Please enter both cost and discount rate.")

root = Tk()
root.title("Calculate Discount Amount")
root.configure(bg='#FF9900')
root.state('normal')
root.update_idletasks()
width = root.winfo_screenwidth()
height = root.winfo_screenheight()
root.geometry(f'{width}x{height}+0+0')

Label(root, text="Cost:", bg='#FF9900', fg='#000000').pack()
cost_entry = Entry(root, bg='#FFF2CC', fg='#000000')
cost_entry.pack()

Label(root, text="Discount Rate (%):", bg='#FF9900', fg='#000000').pack()
discount_rate_entry = Entry(root, bg='#FFF2CC', fg='#000000')
discount_rate_entry.pack()

calculate_button = Button(root, text="Calculate Discount Amount", command=get_discount_amount, bg='#146EB4', fg='#000000')
calculate_button.pack()

root.mainloop()
