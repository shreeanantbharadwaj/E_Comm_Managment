import tkinter as tk
from tkinter import messagebox
import pyodbc

def db_connect():
    try:
        conn = pyodbc.connect(
            'DRIVER={ODBC Driver 17 for SQL Server};'
            'SERVER=localhost,1433;'
            'DATABASE=UniversalMart;'
            'UID=sa;'
            'PWD=Rootroot@97;'
            'TrustServerCertificate=yes;'
            'Timeout=90'
        )
        return conn
    except Exception as e:
        messagebox.showerror("Database Connection", f"Error connecting to database: {e}")
        return None

def insert_item():
    try:
        conn = db_connect()
        if conn:
            cursor = conn.cursor()
            item_id = int(entry_item_id.get())
            item_name = entry_item_name.get()
            cost = float(entry_cost.get())
            details = entry_details.get("1.0", tk.END)
            classification_id = int(entry_classification_id.get())
            cursor.execute("INSERT INTO ITEM (Item_ID, Item_Name, Cost, Details, Classification_ID) VALUES (?, ?, ?, ?, ?)", (item_id, item_name, cost, details, classification_id))
            conn.commit()
            messagebox.showinfo("Success", "Item inserted successfully")
            conn.close()
    except Exception as e:
        messagebox.showerror("Error", f"Error inserting item: {e}")

def update_item():
    try:
        conn = db_connect()
        if conn:
            cursor = conn.cursor()
            item_id = int(entry_item_id.get())
            item_name = entry_item_name.get()
            cost = float(entry_cost.get())
            details = entry_details.get("1.0", tk.END)
            classification_id = int(entry_classification_id.get())
            cursor.execute("UPDATE ITEM SET Item_Name = ?, Cost = ?, Details = ?, Classification_ID = ? WHERE Item_ID = ?", (item_name, cost, details, classification_id, item_id))
            conn.commit()
            messagebox.showinfo("Success", "Item updated successfully")
            conn.close()
    except Exception as e:
        messagebox.showerror("Error", f"Error updating item: {e}")

def view_items():
    try:
        conn = db_connect()
        if conn:
            cursor = conn.cursor()
            cursor.execute("SELECT * FROM ITEM")
            rows = cursor.fetchall()
            if rows:
                item_text.delete('1.0', tk.END)
                for row in rows:
                    item_text.insert(tk.END, f"Item ID: {row[0]}, Item Name: {row[1]}, Cost: {row[2]}, Details: {row[3]}, Classification ID: {row[4]}\n")
            else:
                messagebox.showinfo("No Items", "No items found")
            conn.close()
    except Exception as e:
        messagebox.showerror("Error", f"Error viewing items: {e}")

# Create the GUI
root = tk.Tk()
root.title("Item Management")

# Item ID
label_item_id = tk.Label(root, text="Item ID:")
label_item_id.grid(row=0, column=0)
entry_item_id = tk.Entry(root)
entry_item_id.grid(row=0, column=1)

# Item Name
label_item_name = tk.Label(root, text="Item Name:")
label_item_name.grid(row=1, column=0)
entry_item_name = tk.Entry(root)
entry_item_name.grid(row=1, column=1)

# Cost
label_cost = tk.Label(root, text="Cost:")
label_cost.grid(row=2, column=0)
entry_cost = tk.Entry(root)
entry_cost.grid(row=2, column=1)

# Details
label_details = tk.Label(root, text="Details:")
label_details.grid(row=3, column=0)
entry_details = tk.Text(root, height=4, width=30)
entry_details.grid(row=3, column=1)

# Classification ID
label_classification_id = tk.Label(root, text="Classification ID:")
label_classification_id.grid(row=4, column=0)
entry_classification_id = tk.Entry(root)
entry_classification_id.grid(row=4, column=1)

# Buttons
button_insert = tk.Button(root, text="Insert", command=insert_item)
button_insert.grid(row=5, column=0)


button_update = tk.Button(root, text="Update", command=update_item)
button_update.grid(row=6, column=0)

button_view = tk.Button(root, text="View Items", command=view_items)
button_view.grid(row=6, column=1)

# Text widget to display item data
item_text = tk.Text(root, height=10, width=60)
item_text.grid(row=7, columnspan=2, padx=10, pady=10)

root.mainloop()
