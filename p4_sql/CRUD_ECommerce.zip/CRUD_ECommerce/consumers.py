from datetime import datetime
import tkinter as tk
from tkinter import ttk, messagebox
import pyodbc

# Function to execute a query and optionally return results
def execute_query(query, parameters=None, fetch_results=False, is_stored_procedure=False):
    try:
        conn = pyodbc.connect('DRIVER={ODBC Driver 17 for SQL Server};'
                              'SERVER=localhost,1433;'
                              'DATABASE=UniversalMart;'
                              'UID=sa;'
                              'PWD=Rootroot@97;'
                              'TrustServerCertificate=yes;'
                              'Timeout=90')
        cursor = conn.cursor()
        if is_stored_procedure:
            if parameters is not None:
                cursor.execute(f"{{CALL {query} (?)}}", parameters)
            else:
                cursor.execute(f"{{CALL {query}}}")
        else:
            cursor.execute(query, parameters) if parameters else cursor.execute(query)
        if fetch_results:
            results = cursor.fetchall()
        conn.commit()
        conn.close()
        if fetch_results:
            return results
    except Exception as e:
        messagebox.showerror("Error", f"Error executing query: {e}")
        return []

# Function to add a new consumer
def add_consumer():
    consumer_id = entry_consumer_id.get()
    given_name = entry_given_name.get()
    family_name = entry_family_name.get()
    email_address = entry_email_address.get()  # Set to None if empty string
    contact_number = entry_contact_number.get()  # Set to None if empty string
    postal_address = entry_postal_address.get()
    consumer_status = entry_consumer_status.get()
    starting_date_str = entry_starting_date.get()  # Get starting date string from the entry field

    # Parse starting date string to datetime object
    try:
        starting_date = datetime.strptime(starting_date_str, '%Y-%m-%d').date()
    except ValueError:
        messagebox.showerror("Error", "Invalid starting date format. Please enter date in YYYY-MM-DD format.")
        return

    # Check if starting date is after '2020-01-01'
    if starting_date < datetime(2020, 1, 1).date():
        messagebox.showerror("Error", "Starting date must be after '2020-01-01'.")
        return

    # Convert starting date to string in correct format for SQL query
    starting_date_sql = starting_date.strftime('%Y-%m-%d')

    # Encrypt email address and contact number in SQL query
    query = f"""
    OPEN SYMMETRIC KEY ConsumerKey
    DECRYPTION BY CERTIFICATE ConsumerCert;

    INSERT INTO CONSUMER (Consumer_ID, Given_Name, Family_Name, Email_Address_Encrypted, Contact_Number_Encrypted, Postal_Address, Consumer_Status, Starting_Date) 
    VALUES ('{consumer_id}', '{given_name}', '{family_name}', 
            EncryptByKey(Key_GUID('ConsumerKey'), CONVERT(VARBINARY, '{email_address}')), 
            EncryptByKey(Key_GUID('ConsumerKey'), CONVERT(VARBINARY, '{contact_number}')), 
            '{postal_address}', '{consumer_status}', '{starting_date_sql}');

    CLOSE SYMMETRIC KEY ConsumerKey;
    """
    
    execute_query(query)
    refresh_treeview()

# Function to update an existing consumer
def update_consumer():
    consumer_id = entry_consumer_id.get()
    given_name = entry_given_name.get()
    family_name = entry_family_name.get()
    email_address = entry_email_address.get()
    contact_number = entry_contact_number.get()
    postal_address = entry_postal_address.get()
    consumer_status = entry_consumer_status.get()

    # Encrypt email address and contact number in SQL query
    query = f"""
    OPEN SYMMETRIC KEY ConsumerKey
    DECRYPTION BY CERTIFICATE ConsumerCert;

    UPDATE CONSUMER 
    SET 
        Given_Name='{given_name}', 
        Family_Name='{family_name}', 
        Email_Address_Encrypted = EncryptByKey(Key_GUID('ConsumerKey'), CONVERT(VARBINARY, '{email_address}')),
        Contact_Number_Encrypted = EncryptByKey(Key_GUID('ConsumerKey'), CONVERT(VARBINARY, '{contact_number}')),
        Postal_Address='{postal_address}', 
        Consumer_Status='{consumer_status}' 
    WHERE Consumer_ID='{consumer_id}';

    CLOSE SYMMETRIC KEY ConsumerKey;
    """

    execute_query(query)
    refresh_treeview()

def delete_consumer():
    selected_item = tree.selection()
    
    if selected_item:
        item_values = tree.item(selected_item, 'values')
        consumer_id = item_values[0]  
        
        try:
            # Delete related reviews
            delete_review_query = "DELETE FROM Review WHERE Order_ID IN (SELECT Order_ID FROM [ORDER] WHERE Billing_ID IN (SELECT Billing_ID FROM BILLING WHERE Consumer_ID = ?))"
            execute_query(delete_review_query, parameters=(consumer_id,), is_stored_procedure=False)
            
            # Delete related order line records
            delete_order_line_query = "DELETE FROM ORDER_LINE WHERE Order_ID IN (SELECT Order_ID FROM [ORDER] WHERE Billing_ID IN (SELECT Billing_ID FROM BILLING WHERE Consumer_ID = ?))"
            execute_query(delete_order_line_query, parameters=(consumer_id,), is_stored_procedure=False)
            
            # Delete related order records
            delete_order_query = "DELETE FROM [ORDER] WHERE Billing_ID IN (SELECT Billing_ID FROM BILLING WHERE Consumer_ID = ?)"
            execute_query(delete_order_query, parameters=(consumer_id,), is_stored_procedure=False)
            
            # Delete related billing records
            delete_billing_query = "DELETE FROM BILLING WHERE Consumer_ID = ?"
            execute_query(delete_billing_query, parameters=(consumer_id,), is_stored_procedure=False)
            
            # Finally delete the consumer record
            delete_consumer_query = "DELETE FROM CONSUMER WHERE Consumer_ID = ?"
            execute_query(delete_consumer_query, parameters=(consumer_id,), is_stored_procedure=False)
                
            refresh_treeview()
        except pyodbc.Error as e:
            messagebox.showerror("Error", f"Error executing query: {e}")
    else:
        messagebox.showinfo("Information", "Please select a consumer to delete.")


# Function to refresh the Treeview widget after an operation

# Function to refresh the Treeview widget after an operation
def refresh_treeview():
    for i in tree.get_children():
        tree.delete(i)
        
    query = """
    OPEN SYMMETRIC KEY ConsumerKey
    DECRYPTION BY CERTIFICATE ConsumerCert;

    SELECT Consumer_ID, Given_Name, Family_Name,
           CONVERT(VARCHAR, DecryptByKey(Email_Address_Encrypted)) AS Email_Address,
           CONVERT(VARCHAR, DecryptByKey(Contact_Number_Encrypted)) AS Contact_Number,
           Postal_Address, Consumer_Status, Starting_Date
    FROM CONSUMER;

    CLOSE SYMMETRIC KEY ConsumerKey;
    """
    
    results = execute_query(query, fetch_results=True)
    for row in results:
        # Ensure each row is formatted as a tuple
        row_data = tuple(str(item) for item in row)
        tree.insert("", "end", values=row_data)


# Create the main window
root = tk.Tk()
root.title("Consumer Management")

# Create labels and entry fields for user input
label_consumer_id = tk.Label(root, text="Consumer ID:")
label_consumer_id.grid(row=0, column=0, padx=5, pady=5, sticky='e')
entry_consumer_id = tk.Entry(root)
entry_consumer_id.grid(row=0, column=1, padx=5, pady=5)

label_given_name = tk.Label(root, text="Given Name:")
label_given_name.grid(row=1, column=0, padx=5, pady=5, sticky='e')
entry_given_name = tk.Entry(root)
entry_given_name.grid(row=1, column=1, padx=5, pady=5)

label_family_name = tk.Label(root, text="Family Name:")
label_family_name.grid(row=2, column=0, padx=5, pady=5, sticky='e')
entry_family_name = tk.Entry(root)
entry_family_name.grid(row=2, column=1, padx=5, pady=5)

label_email_address = tk.Label(root, text="Email Address:")
label_email_address.grid(row=3, column=0, padx=5, pady=5, sticky='e')
entry_email_address = tk.Entry(root)
entry_email_address.grid(row=3, column=1, padx=5, pady=5)

label_contact_number = tk.Label(root, text="Contact Number:")
label_contact_number.grid(row=4, column=0, padx=5, pady=5, sticky='e')
entry_contact_number = tk.Entry(root)
entry_contact_number.grid(row=4, column=1, padx=5, pady=5)

label_postal_address = tk.Label(root, text="Postal Address:")
label_postal_address.grid(row=5, column=0, padx=5, pady=5, sticky='e')
entry_postal_address = tk.Entry(root)
entry_postal_address.grid(row=5, column=1, padx=5, pady=5)

label_consumer_status = tk.Label(root, text="Consumer Status:")
label_consumer_status.grid(row=6, column=0, padx=5, pady=5, sticky='e')
entry_consumer_status = tk.Entry(root)
entry_consumer_status.grid(row=6, column=1, padx=5, pady=5)

label_starting_date = tk.Label(root, text="Starting Date (YYYY-MM-DD):")
label_starting_date.grid(row=7, column=0, padx=5, pady=5, sticky='e')
entry_starting_date = tk.Entry(root)
entry_starting_date.grid(row=7, column=1, padx=5, pady=5)

# Buttons for CRUD operations
add_button = tk.Button(root, text="Add Consumer", command=add_consumer)
add_button.grid(row=8, column=0, padx=5, pady=5)

update_button = tk.Button(root, text="Update Consumer", command=update_consumer)
update_button.grid(row=8, column=1, padx=5, pady=5)

delete_button = tk.Button(root, text="Delete Consumer", command=delete_consumer)
delete_button.grid(row=9, column=0, padx=5, pady=5, columnspan=2)

# Treeview widget for displaying consumer records
columns = ("Consumer ID", "Given Name", "Family Name", "Email Address", "Contact Number", "Postal Address", "Consumer Status", "Starting Date")
tree = ttk.Treeview(root, columns=columns, show='headings')
for col in columns:
    tree.heading(col, text=col)
tree.grid(row=10, column=0, columnspan=2, padx=5, pady=5)

# Initialize Treeview with data
refresh_treeview()

# Start the Tkinter event loop
root.mainloop()
