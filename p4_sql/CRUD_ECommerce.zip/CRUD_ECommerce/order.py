import tkinter as tk
from tkinter import messagebox
import pyodbc

def db_connect():
    try:
        conn = pyodbc.connect(
            'DRIVER={ODBC Driver 17 for SQL Server};'
            'SERVER=localhost,1433;'
            'DATABASE=UniversalMart;'
            'UID=sa;'
            'PWD=Rootroot@97;'
            'TrustServerCertificate=yes;'
            'Timeout=90'
        )
        return conn
    except Exception as e:
        messagebox.showerror("Database Connection", f"Error connecting to database: {e}")
        return None

def insert_order():
    try:
        conn = db_connect()
        if conn:
            cursor = conn.cursor()
            order_id = int(entry_order_id.get())
            order_date = entry_order_date.get()
            billing_id = int(entry_billing_id.get())
            consumer_id = int(entry_consumer_id.get())
            delivery_id = int(entry_delivery_id.get())
            cursor.execute("INSERT INTO [ORDER] (Order_ID, Order_Date, Billing_ID, Consumer_ID, Delivery_ID) VALUES (?, ?, ?, ?, ?)", (order_id, order_date, billing_id, consumer_id, delivery_id))
            conn.commit()
            messagebox.showinfo("Success", "Order inserted successfully")
            conn.close()
    except Exception as e:
        messagebox.showerror("Error", f"Error inserting order: {e}")

def delete_order():
    try:
        conn = db_connect()
        if conn:
            cursor = conn.cursor()
            order_id = int(entry_order_id.get())
            cursor.execute("DELETE FROM [ORDER] WHERE Order_ID = ?", (order_id,))
            conn.commit()
            messagebox.showinfo("Success", "Order deleted successfully")
            conn.close()
    except Exception as e:
        messagebox.showerror("Error", f"Error deleting order: {e}")

def update_order():
    try:
        conn = db_connect()
        if conn:
            cursor = conn.cursor()
            order_id = int(entry_order_id.get())
            order_date = entry_order_date.get()
            billing_id = int(entry_billing_id.get())
            consumer_id = int(entry_consumer_id.get())
            delivery_id = int(entry_delivery_id.get())
            cursor.execute("UPDATE [ORDER] SET Order_Date = ?, Billing_ID = ?, Consumer_ID = ?, Delivery_ID = ? WHERE Order_ID = ?", (order_date, billing_id, consumer_id, delivery_id, order_id))
            conn.commit()
            messagebox.showinfo("Success", "Order updated successfully")
            conn.close()
    except Exception as e:
        messagebox.showerror("Error", f"Error updating order: {e}")

root = tk.Tk()
root.title("Order Management")
root.configure(bg='#232F3E')
root.geometry('600x400+100+100')

entry_bg = '#37475A'
entry_fg = '#FFD814'
button_bg = '#FF9900'
button_fg = '#0F1111'
label_fg = '#FFD814'

label_order_id = tk.Label(root, text="Order ID:", bg='#232F3E', fg=label_fg)
label_order_id.grid(row=0, column=0)
entry_order_id = tk.Entry(root, bg=entry_bg, fg=entry_fg)
entry_order_id.grid(row=0, column=1)

label_order_date = tk.Label(root, text="Order Date:", bg='#232F3E', fg=label_fg)
label_order_date.grid(row=1, column=0)
entry_order_date = tk.Entry(root, bg=entry_bg, fg=entry_fg)
entry_order_date.grid(row=1, column=1)

label_billing_id = tk.Label(root, text="Billing ID:", bg='#232F3E', fg=label_fg)
label_billing_id.grid(row=2, column=0)
entry_billing_id = tk.Entry(root, bg=entry_bg, fg=entry_fg)
entry_billing_id.grid(row=2, column=1)

label_consumer_id = tk.Label(root, text="Consumer ID:", bg='#232F3E', fg=label_fg)
label_consumer_id.grid(row=3, column=0)
entry_consumer_id = tk.Entry(root, bg=entry_bg, fg=entry_fg)
entry_consumer_id.grid(row=3, column=1)

label_delivery_id = tk.Label(root, text="Delivery ID:", bg='#232F3E', fg=label_fg)
label_delivery_id.grid(row=4, column=0)
entry_delivery_id = tk.Entry(root, bg=entry_bg, fg=entry_fg)
entry_delivery_id.grid(row=4, column=1)

button_insert = tk.Button(root, text="Insert", command=insert_order, bg=button_bg, fg=button_fg)
button_insert.grid(row=5, column=0)

button_delete = tk.Button(root, text="Delete", command=delete_order, bg=button_bg, fg=button_fg)
button_delete.grid(row=5, column=1)

button_update = tk.Button(root, text="Update", command=update_order, bg=button_bg, fg=button_fg)
button_update.grid(row=6, column=0)

root.mainloop()
