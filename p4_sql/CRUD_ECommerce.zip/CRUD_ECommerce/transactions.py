import tkinter as tk
from tkinter import ttk, messagebox
import pyodbc
 
def db_connect():
    """Establishes a connection to the database and returns the connection object."""
    try:
        conn = pyodbc.connect(
            'DRIVER={ODBC Driver 17 for SQL Server};'
            'SERVER=localhost,1433;'
            'DATABASE=UniversalMart;'
            'UID=sa;'
            'PWD=Rootroot@97;'
            'TrustServerCertificate=yes;'
            'Timeout=90'
        )
        return conn
    except Exception as e:
        messagebox.showerror("Error", f"Error connecting to database: {e}")
        return None

def execute_query(query, parameters=None, fetch_results=False):
    """Executes the given SQL query with optional parameters and fetches results if specified."""
    conn = db_connect()
    if conn is not None:
        try:
            cursor = conn.cursor()
            cursor.execute(query, parameters) if parameters else cursor.execute(query)
            if fetch_results:
                results = cursor.fetchall()
            conn.commit()
            conn.close()
            if fetch_results:
                return results
        except Exception as e:
            messagebox.showerror("Error", f"Error executing query: {e}")

def add_transaction():
    """Inserts a new transaction record into the database."""
    try:
        transaction_id = int(entry_transaction_id.get())
        amount = float(entry_amount.get())
        rebate = float(entry_rebate.get())
        transaction_method = entry_transaction_method.get()
        transaction_status = entry_transaction_status.get()
        
        # Validate transaction status
        if transaction_status not in ['complete', 'pending', 'overdue']:
            messagebox.showerror("Error", "Invalid transaction status. Must be 'complete', 'pending', or 'overdue'.")
            return

        query = """
        INSERT INTO TRANSACTION_INFORMATION (Transaction_ID, Amount, Rebate, Transaction_method, Transaction_Status) 
        VALUES (?, ?, ?, ?, ?)
        """
        execute_query(query, (transaction_id, amount, rebate, transaction_method, transaction_status))
        messagebox.showinfo("Success", "Transaction added successfully.")
        refresh_transactions_treeview()
    except ValueError:
        messagebox.showerror("Error", "Invalid input. Please check your data.")

def update_transaction():
    """Updates the selected transaction's status."""
    selected_item = transactions_tree.selection()
    if selected_item:
        item_values = transactions_tree.item(selected_item, 'values')
        transaction_id = item_values[0]  
        new_status = entry_new_status.get()
        
        # Validate new status
        if new_status not in ['complete', 'pending', 'overdue']:
            messagebox.showerror("Error", "Invalid new status. Must be 'complete', 'pending', or 'overdue'.")
            return

        query = """
        UPDATE TRANSACTION_INFORMATION 
        SET Transaction_Status=?
        WHERE Transaction_ID=?
        """
        execute_query(query, (new_status, transaction_id))
        messagebox.showinfo("Success", "Transaction updated successfully.")
        refresh_transactions_treeview()
    else:
        messagebox.showinfo("Information", "Please select a transaction to update.")

def delete_transaction():
    """Deletes the selected transaction."""
    selected_item = transactions_tree.selection()
    if selected_item:
        item_values = transactions_tree.item(selected_item, 'values')
        transaction_id = item_values[0]  
        
        query = "DELETE FROM TRANSACTION_INFORMATION WHERE Transaction_ID=?"
        execute_query(query, (transaction_id,))
        messagebox.showinfo("Success", "Transaction deleted successfully.")
        refresh_transactions_treeview()
    else:
        messagebox.showinfo("Information", "Please select a transaction to delete.")

def refresh_transactions_treeview():
    """Fetches and displays transactions in the Treeview widget."""
    for i in transactions_tree.get_children():
        transactions_tree.delete(i)
    
    query = """
    SELECT Transaction_ID, Amount, Rebate, Transaction_method, Transaction_Status
    FROM TRANSACTION_INFORMATION
    """
    results = execute_query(query, fetch_results=True)
    if results:
        for row in results:
            # Convert each value to a proper type to ensure correct display.
            formatted_row = [
                int(row[0]),  
                float(row[1]),  
                float(row[2]),  
                str(row[3]),  
                str(row[4])  
            ]
            transactions_tree.insert("", "end", values=formatted_row)

# UI Setup
root = tk.Tk()
root.title("Transaction Management")

# Set window size and position to center
window_width = 800
window_height = 600
screen_width = root.winfo_screenwidth()
screen_height = root.winfo_screenheight()
x_coordinate = int((screen_width - window_width) / 2)
y_coordinate = int((screen_height - window_height) / 2)
root.geometry(f"{window_width}x{window_height}+{x_coordinate}+{y_coordinate}")

root.configure(bg='#FF9900')  

style = ttk.Style(root)
style.theme_use('clam')  # Change to clam theme for better compatibility

style.configure('TButton', foreground='black', background='#FF9900')  
style.configure('TLabel', foreground='black', background='#FF9900')  
style.configure('Treeview', foreground='black', background='white') 
style.map('Treeview', background=[('selected', '#FF9900')])  

# UI Widgets
label_transaction_id = tk.Label(root, text="Transaction ID:")
label_transaction_id.grid(row=0, column=0, padx=5, pady=5, sticky='e')
entry_transaction_id = tk.Entry(root)
entry_transaction_id.grid(row=0, column=1, padx=5, pady=5)

label_amount = tk.Label(root, text="Amount:")
label_amount.grid(row=1, column=0, padx=5, pady=5, sticky='e')
entry_amount = tk.Entry(root)
entry_amount.grid(row=1, column=1, padx=5, pady=5)

label_rebate = tk.Label(root, text="Rebate:")
label_rebate.grid(row=2, column=0, padx=5, pady=5, sticky='e')
entry_rebate = tk.Entry(root)
entry_rebate.grid(row=2, column=1, padx=5, pady=5)

label_transaction_method = tk.Label(root, text="Transaction Method:")
label_transaction_method.grid(row=3, column=0, padx=5, pady=5, sticky='e')
entry_transaction_method = tk.Entry(root)
entry_transaction_method.grid(row=3, column=1, padx=5, pady=5)

label_transaction_status = tk.Label(root, text="Transaction Status:")
label_transaction_status.grid(row=4, column=0, padx=5, pady=5, sticky='e')
entry_transaction_status = tk.Entry(root)
entry_transaction_status.grid(row=4, column=1, padx=5, pady=5)

btn_add_transaction = ttk.Button(root, text="Add Transaction", command=add_transaction)
btn_add_transaction.grid(row=5, column=0, columnspan=2, pady=5)

label_new_status = tk.Label(root, text="New Status for Update:")
label_new_status.grid(row=6, column=0, padx=5, pady=5, sticky='e')
entry_new_status = tk.Entry(root)
entry_new_status.grid(row=6, column=1, padx=5, pady=5)

btn_update_transaction = ttk.Button(root, text="Update Selected Transaction", command=update_transaction)
btn_update_transaction.grid(row=7, column=0, columnspan=2, pady=5)

btn_delete_transaction = ttk.Button(root, text="Delete Selected Transaction", command=delete_transaction)
btn_delete_transaction.grid(row=8, column=0, columnspan=2, pady=5)

columns = ("Transaction_ID", "Amount", "Rebate", "Transaction_method", "Transaction_Status")
transactions_tree = ttk.Treeview(root, columns=columns, show="headings")
for col in columns:
    transactions_tree.heading(col, text=col)
transactions_tree.grid(row=9, column=0, columnspan=2, pady=5)

refresh_transactions_treeview()

root.mainloop()
