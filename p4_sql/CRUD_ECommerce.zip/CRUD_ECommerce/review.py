import pyodbc
from tkinter import *
from tkinter import messagebox
 
def db_connect():
    try:
        conn = pyodbc.connect(
            'DRIVER={ODBC Driver 17 for SQL Server};'
            'SERVER=localhost,1433;'
            'DATABASE=UniversalMart;'
            'UID=sa;'
            'PWD=Rootroot@97;'
            'TrustServerCertificate=yes;'
            'Timeout=90'
        )
        return conn
    except Exception as e:
        messagebox.showerror("Database Connection", f"Error connecting to database: {e}")
        return None

def insert_review():
    try:
        conn = db_connect()
        if conn:
            cursor = conn.cursor()
            order_id = order_id_entry.get()
            consumer_id = consumer_id_entry.get()
            review_text = review_text_entry.get()
            review_rating = review_rating_entry.get()
            review_date = review_date_entry.get()
            cursor.execute("INSERT INTO Review (Order_ID, Consumer_ID, Review_Text, Review_Rating, Review_Date) VALUES (?, ?, ?, ?, ?)",
                           (order_id, consumer_id, review_text, review_rating, review_date))
            conn.commit()
            messagebox.showinfo("Success", "Review inserted successfully.")
    except pyodbc.Error as e:
        messagebox.showerror("Error", f"Error inserting review: {e}")
    finally:
        if conn:
            conn.close()

def clear_fields():
    order_id_entry.delete(0, END)
    consumer_id_entry.delete(0, END)
    review_text_entry.delete(0, END)
    review_rating_entry.delete(0, END)
    review_date_entry.delete(0, END)

root = Tk()
root.title("Review CRUD")
root.configure(bg='#232F3E')

style = {'bg': '#232F3E', 'fg': '#FFD814'}

Label(root, text="Order ID:", **style).grid(row=0, column=0)
order_id_entry = Entry(root)
order_id_entry.grid(row=0, column=1)

Label(root, text="Consumer ID:", **style).grid(row=1, column=0)
consumer_id_entry = Entry(root)
consumer_id_entry.grid(row=1, column=1)

Label(root, text="Review Text:", **style).grid(row=2, column=0)
review_text_entry = Entry(root)
review_text_entry.grid(row=2, column=1)

Label(root, text="Review Rating:", **style).grid(row=3, column=0)
review_rating_entry = Entry(root)
review_rating_entry.grid(row=3, column=1)

Label(root, text="Review Date:", **style).grid(row=4, column=0)
review_date_entry = Entry(root)
review_date_entry.grid(row=4, column=1)

button_style = {'bg': '#FF9900', 'fg': '#0F1111'}
insert_button = Button(root, text="Insert Review", command=insert_review, **button_style)
insert_button.grid(row=5, column=0)

clear_button = Button(root, text="Clear Fields", command=clear_fields, **button_style)
clear_button.grid(row=5, column=1)

root.mainloop()
