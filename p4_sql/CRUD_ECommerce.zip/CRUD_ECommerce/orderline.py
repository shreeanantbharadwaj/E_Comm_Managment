import tkinter as tk
from tkinter import messagebox
import pyodbc

def db_connect():
    try:
        conn = pyodbc.connect(
            'DRIVER={ODBC Driver 17 for SQL Server};'
            'SERVER=localhost,1433;'
            'DATABASE=UniversalMart;'
            'UID=sa;'
            'PWD=Rootroot@97;'
            'TrustServerCertificate=yes;'
            'Timeout=90'
        )
        return conn
    except Exception as e:
        messagebox.showerror("Database Connection", f"Error connecting to database: {e}")
        return None

def insert_order_line():
    try:
        conn = db_connect()
        if conn:
            cursor = conn.cursor()
            order_id = int(entry_order_id.get())
            item_id = int(entry_item_id.get())
            order_qty = int(entry_order_qty.get())
            cursor.execute("INSERT INTO ORDER_LINE (Order_ID, ITEM_ID, Order_QTY) VALUES (?, ?, ?)", (order_id, item_id, order_qty))
            conn.commit()
            messagebox.showinfo("Success", "Order line inserted successfully")
            conn.close()
    except Exception as e:
        messagebox.showerror("Error", f"Error inserting order line: {e}")

def delete_order_line():
    try:
        conn = db_connect()
        if conn:
            cursor = conn.cursor()
            order_id = int(entry_order_id.get())
            cursor.execute("DELETE FROM ORDER_LINE WHERE Order_ID = ?", (order_id,))
            conn.commit()
            messagebox.showinfo("Success", "Order line deleted successfully")
            conn.close()
    except Exception as e:
        messagebox.showerror("Error", f"Error deleting order line: {e}")

def update_order_line():
    try:
        conn = db_connect()
        if conn:
            cursor = conn.cursor()
            order_id = int(entry_order_id.get())
            item_id = int(entry_item_id.get())
            order_qty = int(entry_order_qty.get())
            cursor.execute("UPDATE ORDER_LINE SET ITEM_ID = ?, Order_QTY = ? WHERE Order_ID = ?", (item_id, order_qty, order_id))
            conn.commit()
            messagebox.showinfo("Success", "Order line updated successfully")
            conn.close()
    except Exception as e:
        messagebox.showerror("Error", f"Error updating order line: {e}")

root = tk.Tk()
root.title("Order Line Management")
root.configure(bg='#232F3E')
root.geometry('600x300+100+100')

entry_bg = '#37475A'
entry_fg = '#FFD814'
button_bg = '#FF9900'
button_fg = '#0F1111'
label_fg = '#FFD814'

label_order_id = tk.Label(root, text="Order ID:", bg='#232F3E', fg=label_fg)
label_order_id.grid(row=0, column=0)
entry_order_id = tk.Entry(root, bg=entry_bg, fg=entry_fg)
entry_order_id.grid(row=0, column=1)

label_item_id = tk.Label(root, text="Item ID:", bg='#232F3E', fg=label_fg)
label_item_id.grid(row=1, column=0)
entry_item_id = tk.Entry(root, bg=entry_bg, fg=entry_fg)
entry_item_id.grid(row=1, column=1)

label_order_qty = tk.Label(root, text="Order Quantity:", bg='#232F3E', fg=label_fg)
label_order_qty.grid(row=2, column=0)
entry_order_qty = tk.Entry(root, bg=entry_bg, fg=entry_fg)
entry_order_qty.grid(row=2, column=1)

button_insert = tk.Button(root, text="Insert", command=insert_order_line, bg=button_bg, fg=button_fg)
button_insert.grid(row=3, column=0)

button_delete = tk.Button(root, text="Delete", command=delete_order_line, bg=button_bg, fg=button_fg)
button_delete.grid(row=3, column=1)

button_update = tk.Button(root, text="Update", command=update_order_line, bg=button_bg, fg=button_fg)
button_update.grid(row=4, column=0)

root.mainloop()
