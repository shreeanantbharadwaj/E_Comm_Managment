import pyodbc
from tkinter import *
from tkinter import messagebox

# Function to establish a connection to the database
def db_connect():
    try:
        conn = pyodbc.connect(
            'DRIVER={ODBC Driver 17 for SQL Server};'
            'SERVER=localhost,1433;'
            'DATABASE=UniversalMart;'
            'UID=sa;'
            'PWD=Rootroot@97;'
            'TrustServerCertificate=yes;'
            'Timeout=90'
        )
        return conn
    except Exception as e:
        messagebox.showerror("Database Connection", f"Error connecting to database: {e}")
        return None

# Function to update the item cost in the database
def update_item_cost(item_id, new_cost):
    try:
        conn = db_connect()
        if conn:
            cursor = conn.cursor()
            cursor.execute("EXEC UpdateItemCost ?, ?, ?", (item_id, new_cost, new_cost))
            conn.commit()
            conn.close()
            messagebox.showinfo("Success", "Item cost updated successfully!")
    except Exception as e:
        messagebox.showerror("Error", f"Error updating item cost: {e}")

# Function to handle the update button click event
def update():
    item_id = item_id_entry.get()
    new_cost = new_cost_entry.get()
    if item_id and new_cost:
        update_item_cost(int(item_id), float(new_cost))
    else:
        messagebox.showerror("Error", "Please enter item ID and new cost.")

# Create the main Tkinter window
root = Tk()
root.title("Update Item Cost")

# Set the window size and position
window_width = 300
window_height = 150
screen_width = root.winfo_screenwidth()
screen_height = root.winfo_screenheight()
x_coordinate = int((screen_width - window_width) / 2)
y_coordinate = int((screen_height - window_height) / 2)
root.geometry(f"{window_width}x{window_height}+{x_coordinate}+{y_coordinate}")

bg_color = "#FF9900"  
fg_color = "black"     
btn_color = "#FF9900"  
btn_fg_color = "white" 

# Set background color
root.configure(bg=bg_color)

# Create and place labels and entry fields
item_id_label = Label(root, text="Item ID:", bg=bg_color, fg=fg_color)
item_id_label.grid(row=0, column=0, padx=10, pady=5, sticky=W)
item_id_entry = Entry(root)
item_id_entry.grid(row=0, column=1, padx=10, pady=5)

new_cost_label = Label(root, text="New Cost:", bg=bg_color, fg=fg_color)
new_cost_label.grid(row=1, column=0, padx=10, pady=5, sticky=W)
new_cost_entry = Entry(root)
new_cost_entry.grid(row=1, column=1, padx=10, pady=5)

# Create and place update button
update_button = Button(root, text="Update", command=update, bg=btn_color, fg=btn_fg_color)
update_button.grid(row=2, column=0, columnspan=2, padx=10, pady=10, sticky="we")

# Add padding to the window content
for child in root.winfo_children():
    child.grid_configure(padx=5, pady=5)

# Run the Tkinter event loop
root.mainloop()
