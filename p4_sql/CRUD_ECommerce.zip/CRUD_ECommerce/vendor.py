import tkinter as tk
from tkinter import messagebox, ttk
import pyodbc 

def db_connect():
    try:
        conn = pyodbc.connect(
            'DRIVER={ODBC Driver 17 for SQL Server};'
            'SERVER=localhost,1433;'
            'DATABASE=UniversalMart;'
            'UID=sa;'
            'PWD=Rootroot@97;'
            'TrustServerCertificate=yes;'
            'Timeout=90'
        )
        return conn
    except Exception as e:
        messagebox.showerror("Database Connection", f"Error connecting to database: {e}")
        return None

def insert_vendor():
    try:
        conn = db_connect()
        if conn:
            cursor = conn.cursor()
            vendor_id = int(entry_vendor_id.get())
            vendor_name = entry_vendor_name.get()
            postal_address = entry_vendor_address.get()
            email_address = entry_vendor_email.get()
            contact_number = entry_vendor_contact.get()
            cursor.execute("INSERT INTO Vendor (Vendor_ID, Vendor_Name, Postal_Address, Email_Address, Contact_Number) VALUES (?, ?, ?, ?, ?)", (vendor_id, vendor_name, postal_address, email_address, contact_number))
            conn.commit()
            messagebox.showinfo("Success", "Vendor record inserted successfully")
            conn.close()
    except Exception as e:
        messagebox.showerror("Error", f"Error inserting vendor record: {e}")

def delete_vendor():
    try:
        conn = db_connect()
        if conn:
            cursor = conn.cursor()
            vendor_id = int(entry_vendor_id.get())
            cursor.execute("DELETE FROM Vendor WHERE Vendor_ID = ?", (vendor_id,))
            conn.commit()
            messagebox.showinfo("Success", "Vendor record deleted successfully")
            conn.close()
    except Exception as e:
        messagebox.showerror("Error", f"Error deleting vendor record: {e}")

def update_vendor():
    try:
        conn = db_connect()
        if conn:
            cursor = conn.cursor()
            vendor_id = int(entry_vendor_id.get())
            vendor_name = entry_vendor_name.get()
            postal_address = entry_vendor_address.get()
            email_address = entry_vendor_email.get()
            contact_number = entry_vendor_contact.get()
            cursor.execute("UPDATE Vendor SET Vendor_Name = ?, Postal_Address = ?, Email_Address = ?, Contact_Number = ? WHERE Vendor_ID = ?", (vendor_name, postal_address, email_address, contact_number, vendor_id))
            conn.commit()
            messagebox.showinfo("Success", "Vendor record updated successfully")
            conn.close()
    except Exception as e:
        messagebox.showerror("Error", f"Error updating vendor record: {e}")

def view_vendor():
    try:
        conn = db_connect()
        if conn:
            cursor = conn.cursor()
            cursor.execute("SELECT * FROM Vendor")
            rows = cursor.fetchall()
            if rows:
                # Create a new window to display the data
                view_window = tk.Toplevel()
                view_window.title("Vendor Data")

                # Create a treeview to display the data in table format
                tree = ttk.Treeview(view_window)
                tree["columns"] = ("Vendor ID", "Vendor Name", "Postal Address", "Email Address", "Contact Number")
                tree.heading("#0", text="Index")
                tree.heading("Vendor ID", text="Vendor ID")
                tree.heading("Vendor Name", text="Vendor Name")
                tree.heading("Postal Address", text="Postal Address")
                tree.heading("Email Address", text="Email Address")
                tree.heading("Contact Number", text="Contact Number")

                # Insert data into the treeview
                for i, row in enumerate(rows):
                    tree.insert("", tk.END, text=str(i+1), values=row)

                tree.pack(expand=True, fill="both")
            else:
                messagebox.showinfo("No Data", "No vendor data found")
            conn.close()
    except Exception as e:
        messagebox.showerror("Error", f"Error viewing vendor data: {e}")

# Create the GUI
root = tk.Tk()
root.title("Vendor Management")

# Set background color
root.configure(bg="#FF9900")  

# Vendor ID
label_vendor_id = tk.Label(root, text="Vendor ID:", bg="#FF9900", fg="black")  # Amazon orange background, black font color
label_vendor_id.grid(row=0, column=0)
entry_vendor_id = tk.Entry(root)
entry_vendor_id.grid(row=0, column=1)

# Vendor Name
label_vendor_name = tk.Label(root, text="Vendor Name:", bg="#FF9900", fg="black")  # Amazon orange background, black font color
label_vendor_name.grid(row=1, column=0)
entry_vendor_name = tk.Entry(root)
entry_vendor_name.grid(row=1, column=1)

# Postal Address
label_vendor_address = tk.Label(root, text="Postal Address:", bg="#FF9900", fg="black")  # Amazon orange background, black font color
label_vendor_address.grid(row=2, column=0)
entry_vendor_address = tk.Entry(root)
entry_vendor_address.grid(row=2, column=1)

# Email Address
label_vendor_email = tk.Label(root, text="Email Address:", bg="#FF9900", fg="black")  # Amazon orange background, black font color
label_vendor_email.grid(row=3, column=0)
entry_vendor_email = tk.Entry(root)
entry_vendor_email.grid(row=3, column=1)

# Contact Number
label_vendor_contact = tk.Label(root, text="Contact Number:", bg="#FF9900", fg="black")  # Amazon orange background, black font color
label_vendor_contact.grid(row=4, column=0)
entry_vendor_contact = tk.Entry(root)
entry_vendor_contact.grid(row=4, column=1)

# Buttons
button_insert = tk.Button(root, text="Insert", command=insert_vendor, bg="#FF9900", fg="blue")  # Amazon orange background, white font color
button_insert.grid(row=5, column=0)

button_delete = tk.Button(root, text="Delete", command=delete_vendor, bg="#FF9900", fg="blue")  # Amazon orange background, white font color
button_delete.grid(row=5, column=1)

button_update = tk.Button(root, text="Update", command=update_vendor, bg="#FF9900", fg="blue")  # Amazon orange background, white font color
button_update.grid(row=6, column=0)

button_view = tk.Button(root, text="View", command=view_vendor, bg="#FF9900", fg="blue")  # Amazon orange background, white font color
button_view.grid(row=6, column=1)

root.mainloop()
