import tkinter as tk
from tkinter import messagebox
import pyodbc

# Database connection function
def db_connect():
    try:
        conn = pyodbc.connect(
            'DRIVER={ODBC Driver 17 for SQL Server};'
            'SERVER=localhost,1433;'
            'DATABASE=UniversalMart;'
            'UID=sa;'
            'PWD=Rootroot@97;'
            'TrustServerCertificate=yes;'
            'Timeout=90'
        )
        return conn
    except Exception as e:
        messagebox.showerror("Database Connection", f"Error connecting to database: {e}")
        return None   

# Function to fetch active consumers from the database
def fetch_active_consumers():
    conn = db_connect()
    if conn:
        try:
            cursor = conn.cursor()
            cursor.execute("SELECT * FROM ActiveConsumers")
            rows = cursor.fetchall()
            conn.close()
            return rows
        except Exception as e:
            messagebox.showerror("Error", f"Error fetching data: {e}")
            conn.close()
            return None

# Function to display active consumers in a listbox
def display_active_consumers():
    active_consumers = fetch_active_consumers()
    if active_consumers:
        listbox.delete(0, tk.END)
        for consumer in active_consumers:
            listbox.insert(tk.END, consumer)

amazon_color_primary = "#FF9900"  
amazon_color_secondary = "#232F3E"  
amazon_color_text = "#FFFFFF"  
amazon_color_button = "#FFFFFF"  

# Tkinter setup
root = tk.Tk()
root.title("Active Consumers")
root.geometry("600x400")

root.config(bg=amazon_color_secondary)

screen_width = root.winfo_screenwidth()
screen_height = root.winfo_screenheight()

x = (screen_width - root.winfo_reqwidth()) // 2
y = (screen_height - root.winfo_reqheight()) // 2

root.geometry("+{}+{}".format(x, y))

listbox = tk.Listbox(root, width=80, height=20, bg=amazon_color_secondary, fg=amazon_color_text)
listbox.pack(pady=20)

fetch_button = tk.Button(root, text="Fetch Active Consumers", command=display_active_consumers, bg=amazon_color_primary, fg="#000000")
fetch_button.pack()

root.mainloop()
