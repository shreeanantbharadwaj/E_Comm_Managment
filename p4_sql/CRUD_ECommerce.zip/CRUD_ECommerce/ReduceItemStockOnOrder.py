import pyodbc
from tkinter import *
from tkinter import messagebox

def db_connect():
    try:
        conn = pyodbc.connect(
            'DRIVER={ODBC Driver 17 for SQL Server};'
            'SERVER=localhost,1433;'
            'DATABASE=UniversalMart;'
            'UID=sa;'
            'PWD=Rootroot@97;'
            'TrustServerCertificate=yes;'
            'Timeout=90'
        )
        return conn
    except Exception as e:
        messagebox.showerror("Database Connection", f"Error connecting to database: {e}")
        return None

def insert_order_line(order_id):
    conn = db_connect()
    if conn:
        try:
            cursor = conn.cursor()
            cursor.execute("INSERT INTO ORDER_LINE (Order_ID, ITEM_ID, Order_QTY) VALUES (?, ?, ?)",
                           (order_id, 123457, 2))
            conn.commit()
            messagebox.showinfo("Success", "Order line inserted successfully!")
        except pyodbc.Error as e:
            messagebox.showerror("Error", f"Error inserting order line: {e}")
        finally:
            conn.close()

def get_order_id():
    order_id = order_id_entry.get()
    if order_id:
        insert_order_line(order_id)
    else:
        messagebox.showerror("Error", "Please enter an Order ID.")

# Create a Tkinter window
root = Tk()
root.title("Insert Order Line")
root.configure(bg='#232F3E')

# Styling
label_fg = '#FFD814'
entry_bg = '#37475A'
entry_fg = '#FFFFFF'
button_bg = '#FF9900'
button_fg = '#0F1111'

# Create and pack labels and entry fields with updated styling
Label(root, text="Order ID:", bg='#232F3E', fg=label_fg).pack()
order_id_entry = Entry(root, bg=entry_bg, fg=entry_fg)
order_id_entry.pack()

# Create and pack insert button with updated styling
insert_button = Button(root, text="Insert Order Line", bg=button_bg, fg=button_fg, command=get_order_id)
insert_button.pack()

# Run the Tkinter event loop
root.mainloop()
